#pragma once

#include "avg_degree.h"
#include "cluster.h"