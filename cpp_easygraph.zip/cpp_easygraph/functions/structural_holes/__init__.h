#pragma once

#include "evaluation.h"