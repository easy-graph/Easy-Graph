#pragma once

#include "../../common/common.h"

py::object strongly_connected_components(py::object G);