#pragma once

#include "../../common/common.h"

py::object plain_bfs(py::object G, py::object source);
