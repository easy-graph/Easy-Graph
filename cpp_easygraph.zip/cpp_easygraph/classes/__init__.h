#pragma once

#include "graph.h"
#include "directed_graph.h"
#include "operation.h"