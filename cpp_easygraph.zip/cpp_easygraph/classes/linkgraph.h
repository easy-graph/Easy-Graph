#include "../common/common.h"

struct LinkEdge{
    // 终点
    int to;
    // 边权重 
    double w;
    // 同起点的上一条边的编号
    int next;

};
struct Graph_L{
    int n;
    int e;
    bool is_directed;
    std::vector<int> head;
    std::vector<LinkEdge> edge;
    Graph_L(int vetex_num = 0, bool directed = false){
        n = vetex_num;
        // e = edge_num;
        is_directed = directed;
        if(n > 0){
            // edge.resize(edge_num + 1);
            head.resize(vetex_num + 1);
        }
    }

    void add_edge(const int &u, const int &v, const int &w) {
        LinkEdge le;
        e +=1;
        le.to = v;
        le.w = w;
        le.next = head[u];
        edge.emplace_back(le);
        head[u] = e;
    }
};

struct compare_node {
	compare_node(){} 
    compare_node(int _x, int _d) {x = _x; d = _d;}
	int x, d;	
	bool operator < (const compare_node &rhs) const {
		return d > rhs.d;
	}
};